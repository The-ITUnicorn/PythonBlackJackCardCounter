from cardcounting import *




screen.fill(white)
table = Table()

pygame.init()
pygame.display.set_caption('BlackJack Card Counter - By The IT-Unicorn')
pygame_icon = pygame.image.load('dabunicorn.png')
pygame.display.set_icon(pygame_icon)

pygame_logo = pygame.transform.scale(pygame_icon, (width, height))
screen.blit(pygame_logo, (0,0))

pygame.display.flip()
time.sleep(5)

##MIN BET SELECTION###
minbetselection = True
screen.fill(white)
font = pygame.font.SysFont(None, 24)
img = font.render("What is the Min Bet?", True, blue)
screen.blit(img, (125, 20))
for button in table.minbetselectionbuttonarray:
    button.print()
pygame.display.flip()
while minbetselection:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            minbetselection = False

    for button in table.minbetselectionbuttonarray:
        Mouse_x, Mouse_y = pygame.mouse.get_pos()
        if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
            if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                click = pygame.mouse.get_pressed()
                if click != (0, 0, 0):
                    print("you clicked on " + button.textstr)
                    table.minbet = button.value
                    minbetselection = False
                    time.sleep(.5)


##BET STRATEGY SELECTION###
betstrategyselection = True
screen.fill(white)
font = pygame.font.SysFont(None, 24)
img = font.render("Select Your Bet Strategy:", True, blue)
screen.blit(img, (100, 20))
for button in table.betStrategyarray:
    button.print()
pygame.display.flip()
while betstrategyselection:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            betstrategyselection = False

    for button in table.betStrategyarray:
        Mouse_x, Mouse_y = pygame.mouse.get_pos()
        if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
            if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                click = pygame.mouse.get_pressed()
                if click != (0, 0, 0):
                    print("you clicked on " + button.textstr)
                    table.betStrategy = button.textstr
                    betstrategyselection = False
                    time.sleep(.5)


##DECK COUNT SELECTION###
screen.fill(white)
font = pygame.font.SysFont(None, 24)
img = font.render("How many Decks?", True, blue)
screen.blit(img, (125, 20))
deckcountselection = True

for button in table.deckbuttonarray:
    button.print()
pygame.display.flip()
while deckcountselection:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            deckcountselection = False

    for button in table.deckbuttonarray:
        Mouse_x, Mouse_y = pygame.mouse.get_pos()
        if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
            if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                click = pygame.mouse.get_pressed()
                if click != (0, 0, 0):
                    print("you clicked on " + button.textstr)
                    table.startingdecks = button.value
                    deckcountselection = False
                    time.sleep(.5)


###CARD COUNTING STARTS HERE###
running = True
print("We are starting with " + str(table.startingdecks) + " decks.")
table.remainingdecks = table.startingdecks
while running:
    table.updateDisplay()
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for button in table.buttonarray:
        Mouse_x, Mouse_y = pygame.mouse.get_pos()
        if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
            if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                click = pygame.mouse.get_pressed()
                if click != (0, 0, 0):
                    print("you clicked on " + button.textstr)
                    table.count(button.value)
                    time.sleep(.5)
                    if button.textstr == "RESET":
                        table.reset()