from settings import *

class Button:
    def __init__(self, left, top, length, width, textstr, value):
        self.top = top
        self.left = left
        self.length = length
        self.width = width
        self.textstr = textstr
        self.value = value


    def print(self):
        pygame.draw.rect(screen, black, (self.left, self.top, self.length, self.width))
        font = pygame.font.SysFont(None, 24)
        img = font.render(self.textstr, True, white)
        screen.blit(img, (self.left + 20, self.top + 20))


class Table:
    def __init__(self):
        self.startingdecks = 0
        self.remainingdecks = 0
        self.runningcount = 0
        self.truecount = 0
        self.playeradvantage = (self.truecount - 1) / 2
        self.betStrategy = "MIT Strategy"
        self.minbet = 5
        self.betamount = self.minbet
        self.betunit = self.minbet * 5
        self.buttonarray = []

        pos1button = Button(100, 50, 200, 50, "2 Through 6", 1)
        self.buttonarray.append(pos1button)

        neutralbutton = Button(100, 150, 200, 50, "7 Through 9", 0)
        self.buttonarray.append(neutralbutton)

        neg1button = Button(100, 250, 200, 50, "10 Through Ace", -1)
        self.buttonarray.append(neg1button)

        resetbutton = Button(100, 350, 200, 50, "RESET", 0)
        self.buttonarray.append(resetbutton)


        self.deckbuttonarray = []

        onedeckbutton = Button(150, 50, 100, 50, "1 DECK", 1)
        self.deckbuttonarray.append(onedeckbutton)

        twodeckbutton = Button(150, 125, 100, 50, "2 DECKS", 2)
        self.deckbuttonarray.append(twodeckbutton)

        threedeckbutton = Button(150, 200, 100, 50, "3 DECKS", 3)
        self.deckbuttonarray.append(threedeckbutton)

        fourdeckbutton = Button(150, 275, 100, 50, "4 DECKS", 4)
        self.deckbuttonarray.append(fourdeckbutton)

        fivedeckbutton = Button(150, 350, 100, 50, "5 DECKS", 5)
        self.deckbuttonarray.append(fivedeckbutton)

        sixdeckbutton = Button(150, 425, 100, 50, "6 DECKS", 6)
        self.deckbuttonarray.append(sixdeckbutton)

        fivedeckbutton = Button(150, 500, 100, 50, "7 DECKS", 7)
        self.deckbuttonarray.append(fivedeckbutton)

        sixdeckbutton = Button(150, 575, 100, 50, "8 DECKS", 8)
        self.deckbuttonarray.append(sixdeckbutton)


        self.minbetselectionbuttonarray = []

        onedollarbutton = Button(150, 50, 100, 50, "   $1", 1)
        self.minbetselectionbuttonarray.append(onedollarbutton)

        threedollarbutton = Button(150, 150, 100, 50, "   $3", 3)
        self.minbetselectionbuttonarray.append(threedollarbutton)

        fivedollarbutton = Button(150, 250, 100, 50, "   $5", 5)
        self.minbetselectionbuttonarray.append(fivedollarbutton)

        tendollarbutton = Button(150, 350, 100, 50, "   $10", 10)
        self.minbetselectionbuttonarray.append(tendollarbutton)

        twentydollarbutton = Button(150, 450, 100, 50, "   $20", 20)
        self.minbetselectionbuttonarray.append(twentydollarbutton)

        twentyfivedollarbutton = Button(150, 550, 100, 50, "   $25", 25)
        self.minbetselectionbuttonarray.append(twentyfivedollarbutton)


        self.betStrategyarray = []

        MITstrategybutton = Button(100, 50, 200, 50, "     MIT Strategy", 0)
        self.betStrategyarray.append(MITstrategybutton)

        standardstrategybutton = Button(100, 150, 200, 50, "Standard Strategy", 0)
        self.betStrategyarray.append(standardstrategybutton)


    def count(self,x):
        self.runningcount += x
        self.remainingdecks -= 1/52
        if self.remainingdecks < 1:
            self.remainingdecks = 1
        self.truecount = self.runningcount/self.remainingdecks
        self.playeradvantage = (self.truecount - 1) / 2
        self.updateodds()

    def updateodds(self):
        print("The current true count is: " + str(round(self.truecount, 2)) + ", this gives the player an advantage percentage of " + str(round(self.playeradvantage, 2)) + '%')
        print("There are " + str(round(self.remainingdecks, 2)) + " Decks Remaining")

    def reset(self):
        self.remainingdecks = self.startingdecks
        self.runningcount = 0
        self.truecount = 0

    def printBoard(self):
        for button in self.buttonarray:
            button.print()

    def updateBet(self):
        if self.betStrategy == "     MIT Strategy":
            self.betunit = self.minbet * 5
            if self.truecount < 2:
                self.betamount = self.minbet
            if self.truecount >= 2:
                self.betamount = self.betunit * int(self.truecount - 1)

        if self.betStrategy == "Standard Strategy":
            if self.truecount < 2:
                self.betamount = self.minbet
            if self.truecount >= 2:
                self.betamount = self.minbet * (int(self.truecount) + 1)


    def updateDisplay(self):
        screen.fill(white)
        self.printBoard()
        self.updateBet()
        font = pygame.font.SysFont(None, 24)
        img = font.render('Click A Button For Every Card.', True, blue)
        screen.blit(img, (75, 25))
        img = font.render('If a new deck or shuffle occurs, click RESET.', True, red)
        screen.blit(img, (25, 415))
        img = font.render('RESET will clear all counting data & start fresh.', True, red)
        screen.blit(img, (15, 430))
        img = font.render('True Count:  ' + str(round(self.truecount, 2)), True, blue)
        screen.blit(img, (125, height - 25))
        img = font.render('Running Count:  ' + str(round(self.runningcount, 2)), True, blue)
        screen.blit(img, (125, height - 75))
        img = font.render('Decks Remaining: ' + str(round(self.remainingdecks, 2)), True, blue)
        screen.blit(img, (125, height - 125))
        img = font.render('Bet Amount:  $' + str(self.betamount), True, blue)
        screen.blit(img, (125, height - 175))
