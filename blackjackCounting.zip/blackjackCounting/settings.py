import pygame
import time




height = 650
width = 400

screen = pygame.display.set_mode((width, height))

black = (0,0,0)
white = (255,255,255)
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)

